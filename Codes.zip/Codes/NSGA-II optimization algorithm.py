import warnings
warnings.filterwarnings("ignore")
import geatpy as ea
import numpy as np
from tqdm import tqdm
import pandas as pd
import joblib
model1 = joblib.load(r"D:/XGB model.pkl")
Compare = pd.read_excel(r"D:/SPO output.xlsx", sheet_name="Sheet1")
data1 = pd.read_excel(r"D:/SPO input.xlsx", sheet_name="Sheet1")
low_bound_original = data1.min(axis=0)
high_bound_original = data1.max(axis=0)
fixed_cols = [data1.iloc[:, i] for i in range(38)]
result_dfY = pd.DataFrame(columns=['FCO2'])
result_dfX = pd.DataFrame(columns=["ALK", "DFe", "DIC", "DOC", "Evs", "MP", "NO3", "O2", "PO4", "PP", "SAL",
                                   "sfcWind", "Si", "CDD", "CSDI", "CWD", "FD", "ID", "PRCPTOT", "R10mm", "R1mm",
                                   "R20mm", "R95p", "R99p", "Rx1day", "Rx5day", "SDII", "SU", "TN10p", "TN90p", "TNn",
                                   "TNx", "TR", "TX10p", "TX90p", "TXn", "TXx", "WSDI"])
cum_FCO2_percentage = 0.0
variables_to_compare = ["CDD", "CWD", "PRCPTOT", "R10mm", "R1mm", "R20mm", "R95p", "R99p", "Rx1day", "Rx5day", "SDII",
                        "FD", "ID", "TN10p", "TX10p", "CSDI", "SU", "TN90p", "TNn", "TNx", "TR", "TX90p", "TXn", "TXx",
                        "WSDI"]
cum_percentage_changes = {var: 0.0 for var in variables_to_compare}
for i in tqdm(range(data1.shape[0])):
    low_bound = low_bound_original.copy()
    high_bound = high_bound_original.copy()
    low_bound['ALK'] = fixed_cols[0][i]
    low_bound['DFe'] = fixed_cols[1][i]
    low_bound['DIC'] = fixed_cols[2][i]
    low_bound['DOC'] = fixed_cols[3][i]
    low_bound['Evs'] = fixed_cols[4][i]
    low_bound['MP'] = fixed_cols[5][i]
    low_bound['NO3'] = fixed_cols[6][i]
    low_bound['O2'] = fixed_cols[7][i]
    low_bound['PO4'] = fixed_cols[8][i]
    low_bound['PP'] = fixed_cols[9][i]
    low_bound['SAL'] = fixed_cols[10][i]
    low_bound['sfcWind'] = fixed_cols[11][i]
    low_bound['Si'] = fixed_cols[12][i]
    low_bound['CDD'] = 0.80 * fixed_cols[13][i]
    low_bound['CSDI'] = fixed_cols[14][i]
    low_bound['CWD'] = fixed_cols[15][i]
    low_bound['FD'] = fixed_cols[16][i]
    low_bound['ID'] = fixed_cols[17][i]
    low_bound['PRCPTOT'] = fixed_cols[18][i]
    low_bound['R10mm'] = fixed_cols[19][i]
    low_bound['R1mm'] = fixed_cols[20][i]
    low_bound['R20mm'] = fixed_cols[21][i]
    low_bound['R95p'] = fixed_cols[22][i]
    low_bound['R99p'] = fixed_cols[23][i]
    low_bound['Rx1day'] = fixed_cols[24][i]
    low_bound['Rx5day'] = fixed_cols[25][i]
    low_bound['SDII'] = fixed_cols[26][i]
    low_bound['SU'] = fixed_cols[27][i]
    low_bound['TN10p'] = fixed_cols[28][i]
    low_bound['TN90p'] = fixed_cols[29][i]
    low_bound['TNn'] = fixed_cols[30][i]
    low_bound['TNx'] = fixed_cols[31][i]
    low_bound['TR'] = fixed_cols[32][i]
    low_bound['TX10p'] = fixed_cols[33][i]
    low_bound['TX90p'] = fixed_cols[34][i]
    low_bound['TXn'] = fixed_cols[35][i]
    low_bound['TXx'] = fixed_cols[36][i]
    low_bound['WSDI'] = fixed_cols[37][i]
    high_bound['ALK'] = fixed_cols[0][i]
    high_bound['DFe'] = fixed_cols[1][i]
    high_bound['DIC'] = fixed_cols[2][i]
    high_bound['DOC'] = fixed_cols[3][i]
    high_bound['Evs'] = fixed_cols[4][i]
    high_bound['MP'] = fixed_cols[5][i]
    high_bound['NO3'] = fixed_cols[6][i]
    high_bound['O2'] = fixed_cols[7][i]
    high_bound['PO4'] = fixed_cols[8][i]
    high_bound['PP'] = fixed_cols[9][i]
    high_bound['SAL'] = fixed_cols[10][i]
    high_bound['sfcWind'] = fixed_cols[11][i]
    high_bound['Si'] = fixed_cols[12][i]
    high_bound['CDD'] = fixed_cols[13][i]
    high_bound['CSDI'] = fixed_cols[14][i]
    high_bound['CWD'] = 1.20 * fixed_cols[15][i]
    high_bound['FD'] = fixed_cols[16][i]
    high_bound['ID'] = fixed_cols[17][i]
    high_bound['PRCPTOT'] = 1.20 * fixed_cols[18][i]
    high_bound['R10mm'] = 1.20 * fixed_cols[19][i]
    high_bound['R1mm'] = 1.20 * fixed_cols[20][i]
    high_bound['R20mm'] = 1.20 * fixed_cols[21][i]
    high_bound['R95p'] = 1.20 * fixed_cols[22][i]
    high_bound['R99p'] = 1.20 * fixed_cols[23][i]
    high_bound['Rx1day'] = 1.20 * fixed_cols[24][i]
    high_bound['Rx5day'] = 1.20 * fixed_cols[25][i]
    high_bound['SDII'] = 1.20 * fixed_cols[26][i]
    high_bound['SU'] = fixed_cols[27][i]
    high_bound['TN10p'] = fixed_cols[28][i]
    high_bound['TN90p'] = fixed_cols[29][i]
    high_bound['TNn'] = fixed_cols[30][i]
    high_bound['TNx'] = fixed_cols[31][i]
    high_bound['TR'] = fixed_cols[32][i]
    high_bound['TX10p'] = fixed_cols[33][i]
    high_bound['TX90p'] = fixed_cols[34][i]
    high_bound['TXn'] = fixed_cols[35][i]
    high_bound['TXx'] = fixed_cols[36][i]
    high_bound['WSDI'] = fixed_cols[37][i]
    variables = ["ALK", "DFe", "DIC", "DOC", "Evs", "MP", "NO3", "O2", "PO4", "PP", "SAL",
                 "sfcWind", "Si", "CDD", "CSDI", "CWD", "FD", "ID", "PRCPTOT", "R10mm", "R1mm",
                 "R20mm", "R95p", "R99p", "Rx1day", "Rx5day", "SDII", "SU", "TN10p", "TN90p", "TNn",
                 "TNx", "TR", "TX10p", "TX90p", "TXn", "TXx", "WSDI"]
    low_bound[variables] = low_bound[variables].clip(lower=0)
    high_bound[variables] = high_bound[variables].clip(lower=0)
    class MyProblem(ea.Problem):
        def __init__(self):
            name = 'NSGA-II'
            M = 1
            maxormins = [1]
            Dim = 38
            varTypes = [0] * 38
            lb = low_bound.values
            ub = high_bound.values
            lbin = [1] * 38
            ubin = [1] * 38
            super().__init__(name, M, maxormins, Dim, varTypes, lb, ub, lbin, ubin)
        def evalVars(self, Vars):
            X = Vars
            f1 = model1.predict(X)
            ObjV = f1[:, np.newaxis]
            CV = None
            return ObjV, CV
    problem = MyProblem()
    algorithm = ea.moea_NSGA2_templet(
        problem,
        ea.Population(Encoding='RI', NIND=100),
        MAXGEN=100,
        logTras=0
    )
    res = ea.optimize(algorithm, seed=1, verbose=False, drawing=0, outputMsg=False, drawLog=False, saveFlag=False)
    ObjV = res['ObjV']
    Vars = res['Vars']
    dfY = pd.DataFrame(ObjV)
    dfX = pd.DataFrame(Vars)
    max_percentage = float('-inf')
    max_index = None
    for a in range(len(dfY)):
        percentage = (Compare['FCO2'].iloc[i] - dfY.iloc[a, 0]) / Compare['FCO2'].iloc[i]
        if percentage > max_percentage:
            max_percentage = percentage
            max_index = a
    best_dfY = dfY.iloc[max_index]
    best_dfX = dfX.iloc[max_index]
    best_dfY = pd.DataFrame([best_dfY])
    best_dfX = pd.DataFrame([best_dfX])
    best_dfY.columns = ['FCO2']
    best_dfX.columns = ["ALK", "DFe", "DIC", "DOC", "Evs", "MP", "NO3", "O2", "PO4", "PP", "SAL",
                        "sfcWind", "Si", "CDD", "CSDI", "CWD", "FD", "ID", "PRCPTOT", "R10mm", "R1mm",
                        "R20mm", "R95p", "R99p", "Rx1day", "Rx5day", "SDII", "SU", "TN10p", "TN90p", "TNn",
                        "TNx", "TR", "TX10p", "TX90p", "TXn", "TXx", "WSDI"]
    FCO2_original = Compare['FCO2'].iloc[i]
    FCO2_optimized = best_dfY['FCO2'].iloc[0]
    if FCO2_original != 0:
        FCO2_percentage = ((FCO2_optimized - FCO2_original) / FCO2_original) * 100
    else:
        FCO2_percentage = 0.0
    cum_FCO2_percentage += FCO2_percentage
    average_FCO2_percentage = cum_FCO2_percentage / (i + 1)
    percentage_changes = {}
    average_percentage_changes = {}
    for var in variables_to_compare:
        original_value = data1[var].iloc[i]
        optimized_value = best_dfX[var].iloc[0]
        if original_value != 0:
            percentage_change = ((optimized_value - original_value) / original_value) * 100
        else:
            percentage_change = 0.0
        percentage_changes[var] = percentage_change
        cum_percentage_changes[var] += percentage_change
        average_percentage_changes[var] = cum_percentage_changes[var] / (i + 1)
    result_dfY = result_dfY._append(best_dfY, ignore_index=True)
    result_dfX = result_dfX._append(best_dfX, ignore_index=True)
with pd.ExcelWriter(r"D:/SPO 1.20.xlsx") as writer:
    result_dfX.to_excel(writer, sheet_name='Prediction-X', index=False)
    result_dfY.to_excel(writer, sheet_name='Prediction-Y', index=False)