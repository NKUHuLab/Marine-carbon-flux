import pandas as pd
import matplotlib.pyplot as plt
from xgboost import XGBRegressor
from sklearn.inspection import PartialDependenceDisplay
from sklearn.model_selection import train_test_split
import os
from tqdm import tqdm
import numpy as np
import joblib
import matplotlib
import os
from tqdm import tqdm
from sklearn.inspection import partial_dependence
import warnings
from itertools import combinations
import warnings
warnings.filterwarnings("ignore")
matplotlib.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
file_path = r"D:/All data.csv"
xgb = joblib.load(r"D:/XGB model.pkl")
data = pd.read_csv(file_path)
base_name = os.path.basename(file_path)
base_name_no_ext = os.path.splitext(base_name)[0]
region_filter = "South Pacific Ocean"
directory_path = f"D:/PDP {base_name_no_ext}_{region_filter}"
if not os.path.exists(directory_path):
    os.makedirs(directory_path)
filtered_data_region = data[data['marine_region'] == region_filter]
filtered_data = filtered_data_region.iloc[:, 6:]
features = filtered_data.iloc[:, 1:]
X = filtered_data.drop(columns=['FCO2'])
y = filtered_data['FCO2']
alk_features = ['ALK']
sal_features = ["SAL"]
desired_combinations = list(combinations(alk_features + sal_features, 2))
filtered_combinations = [comb for comb in desired_combinations if (comb[0] in alk_features and comb[1] in sal_features) or (comb[0] in sal_features and comb[1] in alk_features)]
test_sizes = [0.15]
for test_size in test_sizes:
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=0)
    xgb.fit(X_train, y_train)
    for sal_feature in tqdm(sal_features):
        feature_pair = ('ALK', sal_feature)
        try:
            pdp_results = partial_dependence(xgb, X_train, features=feature_pair, grid_resolution=100)
            XX, YY = np.meshgrid(pdp_results['values'][0], pdp_results['values'][1])
            Z = pdp_results['average'][0].reshape(XX.shape)
            fig, ax = plt.subplots(figsize=(6.5, 4))
            contourf = ax.contourf(XX, YY, Z, cmap='BrBG_r')
            ax.set_xlabel("ALK (mol·m-3)", fontsize=16)
            ax.set_ylabel("SAL (‰)", fontsize=16)
            plt.xticks(fontsize=14)
            plt.yticks(fontsize=14)
            cbar = fig.colorbar(contourf, ax=ax, label='FCO2 (GtC·year-1)')
            cbar.set_label('FCO2 (GtC·year-1)', fontsize=16)
            cbar.ax.tick_params(labelsize=16)
            fig.subplots_adjust(left=0.16, right=0.9, bottom=0.15, top=0.95)
            new_base_name = f"{base_name_no_ext}"
            pdf_filename = os.path.join(
                directory_path,
                f"{test_size}-ALK-{sal_feature}-{region_filter}-{new_base_name}-grid_resolution=100.pdf"
            )
            fig.savefig(pdf_filename, dpi=600)
            plt.close(fig)
        except ValueError as e:
            print(f"Error occurred for feature pair {feature_pair}: {e}")