import warnings
warnings.filterwarnings("ignore")
from itertools import product
from sklearn.model_selection import ShuffleSplit
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
from xgboost import XGBRegressor
from tqdm import tqdm
import numpy as np
import pandas as pd
import random
import seaborn as sns
import matplotlib.pyplot as plt
import joblib
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
import matplotlib
matplotlib.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
def mape(obs, pre):
    return np.mean(np.abs((obs - pre) / obs)) * 100
def rmse(obs, pre):
    return np.sqrt(mean_squared_error(obs, pre))
def calculate_cor():
    global r_test, r_train, y_test_pred, y_train_pred, rmse_test, rmse_train, mae_test, mae_train, mape_test, mape_train
    y_test_pred = pd.DataFrame(model.predict(x_test).reshape(-1, 1), index=test_index)
    y_train_pred = pd.DataFrame(model.predict(x_train).reshape(-1, 1), index=train_index)
    r_test = r2_score(y_test[colnames[0]], y_test_pred[0])
    r_train = r2_score(y_train[colnames[0]], y_train_pred[0])
    rmse_test = rmse(y_test[colnames[0]], y_test_pred[0])
    rmse_train = rmse(y_train[colnames[0]], y_train_pred[0])
    mae_test = mean_absolute_error(y_test[colnames[0]], y_test_pred[0])
    mae_train = mean_absolute_error(y_train[colnames[0]], y_train_pred[0])
    mape_test = mape(y_test[colnames[0]], y_test_pred[0])
    mape_train = mape(y_train[colnames[0]], y_train_pred[0])
n_estimators_list = [300,400,500]
max_depth_list = [3,4,5]
total_iterations = len(n_estimators_list) * len(max_depth_list)
parameter_combinations = product(n_estimators_list, max_depth_list)
results_dict = {}
for n_estimators, max_depth in tqdm(parameter_combinations, total=total_iterations):
    model = XGBRegressor(n_estimators=n_estimators, random_state=0, max_depth=max_depth)
    frame = pd.read_csv(r"D:/All data after isolation forest screening.csv")
    random.seed(0)
    val = random.sample(range(0, len(frame)), 5)
    model_index = list(frame.index)
    for j in val:
        model_index.remove(j)
    valdata = frame.loc[val, :]
    val_x = valdata.iloc[:, 7:]
    val_y = valdata.iloc[:, 6:7]
    frame = frame.loc[model_index, :]
    x_data = frame.iloc[:, 7:]
    x_data.index = range(len(x_data))
    y_data = frame.iloc[:, 6:7]
    y_data.index = range(len(y_data))
    x_names = x_data.columns.values.tolist()
    y_names = y_data.columns.values.tolist()
    colnames = y_data.columns.values.tolist()
    ss = ShuffleSplit(n_splits=5, test_size=0.3, random_state=0)
    stdsc = StandardScaler()
    corlist_train = []
    corlist_test = []
    rmsel_train = []
    rmsel_test = []
    o = []
    mae_list_train = []
    mae_list_test = []
    mape_list_train = []
    mape_list_test = []
    imp = []
    for train_index, test_index in tqdm(ss.split(x_data, y_data), total=ss.get_n_splits()):
        x_train = x_data.iloc[train_index, :]
        x_train.columns = x_names
        y_train = y_data.iloc[train_index, :]
        x_test = x_data.iloc[test_index, :]
        x_test.columns = x_names
        y_test = y_data.iloc[test_index, :]
        model.fit(x_train, np.array(y_train).ravel())
        calculate_cor()
        corlist_train.append(r_train)
        corlist_test.append(r_test)
        rmsel_train.append(rmse_train)
        rmsel_test.append(rmse_test)
        o.append(y_train[colnames[0]])
        o.append(y_train_pred[0])
        o.append(y_test[colnames[0]])
        o.append(y_test_pred[0])
        mae_train = mean_absolute_error(y_train, y_train_pred[0])
        mae_test = mean_absolute_error(y_test, y_test_pred[0])
        mape_train = mape(y_train[colnames[0]], y_train_pred[0])
        mape_test = mape(y_test[colnames[0]], y_test_pred[0])
        mae_list_train.append(mae_train)
        mae_list_test.append(mae_test)
        mape_list_train.append(mape_train)
        mape_list_test.append(mape_test)
        imp.append(model.feature_importances_)
    cordf = pd.DataFrame(
        {'train': corlist_train, 'test': corlist_test, 'rmse_train': rmsel_train, 'rmse_test': rmsel_test})
    mean_train_r2 = cordf['train'].mean()
    mean_test_r2 = cordf['test'].mean()
    mean_rmse_train = cordf['rmse_train'].mean()
    mean_rmse_test = cordf['rmse_test'].mean()
    param_tuple = (n_estimators, max_depth)
    mean_mae_train = np.mean(mae_list_train)
    mean_mae_test = np.mean(mae_list_test)
    mean_mape_train = np.mean(mape_list_train)
    mean_mape_test = np.mean(mape_list_test)
    train_r2_str = ",".join(map(str, corlist_train))
    test_r2_str = ",".join(map(str, corlist_test))
    rmse_train_str = ",".join(map(str, rmsel_train))
    rmse_test_str = ",".join(map(str, rmsel_test))
    mae_train_str = ",".join(map(str, mae_list_train))
    mae_test_str = ",".join(map(str, mae_list_test))
    mape_train_str = ",".join(map(str, mape_list_train))
    mape_test_str = ",".join(map(str, mape_list_test))
    results_dict[param_tuple] = {'n_estimators': n_estimators, 'max_depth': max_depth,
                                 'mean_train_r2': mean_train_r2, 'mean_test_r2': mean_test_r2,
                                 'rmse_train': mean_rmse_train, 'rmse_test': mean_rmse_test,
                                 'mean_mae_train': mean_mae_train, 'mean_mae_test': mean_mae_test,
                                 'mean_mape_train': mean_mape_train, 'mean_mape_test': mean_mape_test,
                                 'train_r2_values': train_r2_str, 'test_r2_values': test_r2_str,
                                 'rmse_train_values': rmse_train_str, 'rmse_test_values': rmse_test_str,
                                 'mae_train_values': mae_train_str, 'mae_test_values': mae_test_str,
                                 'mape_train_values': mape_train_str, 'mape_test_values': mape_test_str}
    results_df = pd.DataFrame.from_dict(results_dict, orient='index')
    results_df.sort_values('mean_test_r2', ascending=False, inplace=True)
    base_path = "D:/"
    results_df.to_excel(f"{base_path} result {n_estimators} {max_depth}.xlsx", index=False)
    model_path = f"{base_path} result {n_estimators} {max_depth}.pkl"
    joblib.dump(model, model_path)