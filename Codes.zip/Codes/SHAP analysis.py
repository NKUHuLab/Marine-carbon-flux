import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
import sklearn.metrics as metrics
import joblib
df = pd.read_csv(r"D:/All data.csv")
X = df.iloc[:, 7:]
y = df['FCO2']
xgb = joblib.load(r"D:/XGB model.pkl")
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
xgb.fit(X_train, y_train)
background = shap.maskers.Independent(X_train, max_samples=100)
explainer = shap.TreeExplainer(xgb, data=background, feature_names=X.columns)
shap_values = explainer(X, check_additivity=False)
shap_df = pd.DataFrame(shap_values.values, columns=shap_values.feature_names)
df_first_six = df.iloc[:, :6].reset_index(drop=True)
shap_df = pd.concat([df_first_six, shap_df], axis=1)
shap_df.to_excel(f"D:/SHAP result.xlsx", index=False)