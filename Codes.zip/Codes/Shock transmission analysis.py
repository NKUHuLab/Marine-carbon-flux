import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.tsa.api import VAR
from statsmodels.tsa.stattools import adfuller
from tqdm import tqdm
import io
import warnings
import matplotlib
from scipy.stats import zscore
from sklearn.linear_model import LinearRegression
from scipy.stats.mstats import winsorize
from sklearn.preprocessing import (MaxAbsScaler, MinMaxScaler, RobustScaler, StandardScaler, PowerTransformer, QuantileTransformer)
warnings.filterwarnings('ignore')
matplotlib.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
os.chdir(r"D:/")
def run_analysis(region_label):
    file_path = f'D:/{region_label} Shock transmission analysis.csv'
    data = pd.read_csv(file_path)
    cols_to_scale = ["PRCPTOT", "FCO2"]
    subset = data[cols_to_scale].dropna()
    scaler = QuantileTransformer(output_distribution='normal', random_state=0)
    scaled_values = scaler.fit_transform(subset)
    data.loc[subset.index, "PRCPTOT"] = scaled_values[:, 0]
    data.loc[subset.index, "FCO2"] = scaled_values[:, 1]
    first_column = "FCO2"
    second_columns = ["PRCPTOT"]
    third_columns = ["ALK"]
    for second_col in tqdm(second_columns):
        for third_col in third_columns:
            combination_name = f"FCO2-{second_col}-{third_col}"
            df = data[[first_column, second_col, third_col]].dropna()
            returns = np.log(df / df.shift(1)).dropna()
            returns_cleaned = returns[~returns.isin([np.inf, -np.inf]).any(axis=1)]
            model = VAR(endog=returns_cleaned)
            lags = range(1, 10)
            criterion = 'aic'
            criteria = []
            for lag in lags:
                result = model.fit(lag)
                criteria.append(result.info_criteria[criterion])
            best_lag = lags[criteria.index(min(criteria))]
            results = model.fit(best_lag)
            irf = results.irf(10)
            fig = irf.plot_cum_effects(orth=True, figsize=(10, 10))
            fig_new, axes_new = plt.subplots(1, 2, figsize=(10, 5))
            keep_indices = [7, 2]
            curve_data = pd.DataFrame()
            fit_lines = []
            horizontal_line_values = []
            for i, ax in enumerate(axes_new):
                original_ax = fig.axes[keep_indices[i]]
                for j, line in enumerate(original_ax.lines):
                    x_data = line.get_xdata()
                    y_data = line.get_ydata()
                    if j == 0:
                        ax.plot(x_data, y_data, color='red', linestyle='-', linewidth=2)
                        curve_data[f'curve_{i + 1}_middle'] = y_data
                        X = x_data.reshape(-1, 1)
                        Y = y_data.reshape(-1, 1)
                        reg = LinearRegression().fit(X, Y)
                        slope = reg.coef_[0][0]
                        intercept = reg.intercept_[0]
                        fit_lines.append((slope, intercept))
                    elif j == 1 or j == 2:
                        ax.plot(x_data, y_data, color='green', linestyle='--', linewidth=2)
                        curve_data[f'curve_{i + 1}_up and down_{j}'] = y_data
                    else:
                        ax.plot(x_data, y_data, color='black', linestyle='-', linewidth=2)
                        if j == 4:
                            horizontal_line_values.append(y_data[0])
                original_title = original_ax.get_title()
                ax.set_title(original_title, fontsize=14)
                ax.tick_params(axis='both', which='major', labelsize=10)
                ax.set_xticks([0, 2, 4, 6, 8, 10])
                ax.set_xticklabels([0, 2, 4, 6, 8, 10])
            slope_signs = []
            for slope, _ in fit_lines:
                if slope < 0:
                    slope_signs.append("negative")
                else:
                    slope_signs.append("positive")
            horizontal_line_5_values = [f"y = {value}" for value in horizontal_line_values]
            file_name = (f"aic normal {region_label}" + combination_name + " ".join(slope_signs) + " " + " ".join(horizontal_line_5_values) + ".pdf")
            plt.tight_layout()
            plt.savefig(file_name)
            plt.close('all')
if __name__ == "__main__":
    run_analysis("SPO")
    run_analysis("SAO")