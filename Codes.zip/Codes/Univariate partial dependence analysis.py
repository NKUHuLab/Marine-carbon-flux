import pandas as pd
import matplotlib.pyplot as plt
from xgboost import XGBRegressor
from sklearn.inspection import PartialDependenceDisplay
from sklearn.model_selection import train_test_split
import os
from tqdm import tqdm
import numpy as np
import joblib
import matplotlib
import os
from tqdm import tqdm
from sklearn.inspection import partial_dependence
import warnings
warnings.filterwarnings("ignore")
matplotlib.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
file_path = r"D:/All data.csv"
data = pd.read_csv(file_path)
base_name = os.path.basename(file_path)
base_name_no_ext = os.path.splitext(base_name)[0]
xgb = joblib.load(r"D:/XGB model.pkl")
region_filter = "South Pacific Ocean"
directory_path = f"D:/{base_name_no_ext}_{region_filter}"
if not os.path.exists(directory_path):
    os.makedirs(directory_path)
filtered_data_region = data[data['marine_region'] == region_filter]
filtered_data = filtered_data_region.iloc[:, 6:]
features = filtered_data.iloc[:, 1:]
X = filtered_data.drop(columns=['FCO2'])
y = filtered_data['FCO2']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
xgb.fit(X_train, y_train)
feature_names = features.columns
target_columns = ["PRCPTOT"]
feature_names = [feature for feature in feature_names if feature in target_columns]
data_frames = []
for feature in tqdm(feature_names, desc=f"Progress for {region_filter}", total=len(feature_names)):
    try:
        pdp_results = partial_dependence(xgb, X_train, [feature], grid_resolution=100)
        x_values = pdp_results['values'][0]
        pd_values = pdp_results['average'][0]
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.plot(x_values, pd_values, color='#670099', linestyle='-', linewidth=2.5)
        min_pd_index = np.argmin(pd_values)
        max_pd_index = np.argmax(pd_values)
        x1, y1 = x_values[min_pd_index], np.min(pd_values)
        x2, y2 = x_values[max_pd_index], np.max(pd_values)
        range_value = y2 - y1
        if range_value != 0:
            if y1 < 0 and y2 < 0:
                plt.ylim(1.05 * y1, 0.95 * y2)
            elif y1 > 0 and y2 > 0:
                plt.ylim(0.95 * y1, 1.05 * y2)
            plt.xlabel(f'{feature}', fontsize=20)
            plt.ylabel('FCO2', fontsize=20)
            plt.xticks(fontsize=16)
            plt.yticks(fontsize=16)
            file_name = f'{directory_path}/{sign_prefix}{range_value}-{feature}-{region_filter}-{base_name_no_ext}-PDP.pdf'
            plt.savefig(file_name)
            plt.close(fig)
        else:
            plt.close(fig)
        data_frames.append(pd.DataFrame({
            "File name": [base_name_no_ext],
            "Marine region": [region_filter],
            "Feature": [feature],
            "Min PD Value": [y1],
            "Max PD Value": [y2],
            "Range": [range_value]
        }))
    except ValueError as e:
        print(f"Error occurred for feature {feature}: {e}")
        continue