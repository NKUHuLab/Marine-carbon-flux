import warnings
warnings.filterwarnings("ignore")
import dowhy
from tqdm import tqdm
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import re
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LassoCV
from xgboost import XGBRegressor
from sklearn.model_selection import KFold
import os
import pygraphviz as pgv
import matplotlib
matplotlib.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
wet_and_drys = ["SDII"]
hot_and_colds = ["TNx"]
dataset = pd.read_csv(r'D:/All data.csv')
dataset = dataset[dataset['marine_region'] == "South Atlantic Ocean"]
save_dir_base = r"D:/XGB Causal"
specific_save_dir = os.path.join(save_dir_base, "SDII_TNx")
os.makedirs(specific_save_dir, exist_ok=True)
paths = [
    ("SDII", "FCO2"),
    ("TNx", "FCO2"),
    ("MP", "PP"),
    ("PP", "FCO2"),
    ("DIC", "FCO2"),
    ("sfcWind", "FCO2"),
    ("SAL", "FCO2"),
    ("Evs", "ALK"),
    ("SDII", "ALK"),
    ("Evs", "SAL"),
    ("SDII", "SAL"),
    ("ALK", "PP"),
    ("TNx", "PP"),
    ("SAL", "O2"),
    ("PP", "O2"),
    ("TNx", "O2"),
    ("sfcWind", "Evs"),
    ("PP", "DIC"),
    ("DFe", "PP"),
    ("NO3", "PP"),
    ("PO4", "PP"),
    ("Si", "PP"),
    ("DOC", "DIC")
]
causal_graph = f"""digraph {{
    {' '.join([f'{a} -> {b};' for a, b in paths])}
}}"""
graph = pgv.AGraph(string=causal_graph)
graph.layout(prog='dot')
graph_filename = os.path.join(specific_save_dir, 'causal plot.pdf')
graph.draw(graph_filename, format='pdf')
n_splits = 5
cv = KFold(n_splits=n_splits, shuffle=True, random_state=0)
summary_results = []
proceed_to_next = True
for path_index, (treatment, outcome) in enumerate(tqdm(paths)):
    if not proceed_to_next:
        break
    try:
        model = dowhy.CausalModel(
            data=dataset,
            graph=causal_graph.replace("/n", " "),
            treatment=treatment,
            outcome=outcome
        )
        identified_estimand = model.identify_effect(proceed_when_unidentifiable=True)
        results = []
        for _ in tqdm(range(5), desc=f"{treatment} -> {outcome}", leave=False):
            dml_estimate = model.estimate_effect(
                identified_estimand,
                method_name="backdoor.econml.dml.DML",
                control_value=0,
                treatment_value=1,
                confidence_intervals=False,
                method_params={
                    "init_params": {
                        'model_y': XGBRegressor(random_state=0),
                        'model_t': XGBRegressor(random_state=0),
                        "model_final": LassoCV(fit_intercept=False, random_state=0),
                        'featurizer': PolynomialFeatures(degree=2, include_bias=True)
                    },
                    "fit_params": {},
                    'cv': cv
                }
            )
            dml_estimate = str(dml_estimate)
            mean_value = re.findall(r"Mean value: ([-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?)", dml_estimate)[0]
            mean_value = float(mean_value)
            results.append(mean_value)
        if not results:
            summary_results.append((f"{treatment} -> {outcome}", None, None, None))
            continue
        df = pd.DataFrame({'Mean Value': results})
        results = df.to_numpy().flatten()
        n_bootstraps = 1000
        confidence_level = 0.95
        bootstrap_estimates = []
        for _ in range(n_bootstraps):
            bootstrap_sample = np.random.choice(results, size=len(results), replace=True)
            bootstrap_estimate = np.mean(bootstrap_sample)
            bootstrap_estimates.append(bootstrap_estimate)
        lower_bound = np.percentile(bootstrap_estimates, (1 - confidence_level) / 2 * 100)
        upper_bound = np.percentile(bootstrap_estimates, (1 + confidence_level) / 2 * 100)
        mean_result = np.mean(results)
        summary_results.append((f"{treatment} -> {outcome}", lower_bound, upper_bound, mean_result))
        plt.figure(figsize=(8, 5))
        plt.hist(bootstrap_estimates, bins=30, alpha=0.5, color='#A4E192')
        plt.axvline(lower_bound, color='r', linestyle='dashed', linewidth=2,
                    label=f'Lower Bound ({confidence_level * 100}% CI)')
        plt.axvline(upper_bound, color='r', linestyle='dashed', linewidth=2,
                    label=f'Upper Bound ({confidence_level * 100}% CI)')
        plt.axvline(mean_result, color='#4AD2D1', linestyle='solid', linewidth=2, label='Mean')
        plt.legend()
        plt.xlabel('Estimates')
        plt.ylabel('Frequency')
        plt.title(f'{treatment} -> {outcome} - {confidence_level * 100}% Confidence Interval')
        image_path = os.path.join(specific_save_dir, f'{treatment}_to_{outcome}_Causal_Confidence Interval.pdf')
        plt.savefig(image_path)
        plt.close()
    except ValueError as e:
        print(f"Skipping path {treatment} -> {outcome} due to error: {e}")
        summary_results.append((f"{treatment} -> {outcome}", None, None, None))
summary_df = pd.DataFrame(summary_results, columns=['Path', 'Lower Bound', 'Upper Bound', 'Mean'])
summary_df.to_excel("D:/Causal results.xlsx", index=False)