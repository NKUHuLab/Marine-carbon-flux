import pandas as pd
import numpy as np
import joblib
from copy import deepcopy
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
from tqdm import tqdm
noise_level = 0.1
test_size = 0.4
estimator_change = 100
data = pd.read_csv(r"D:/All data.csv")
data2 = data.copy()
data = data.iloc[:, 6:]
attributes = [
    'ALK', 'DFe', 'DIC', 'DOC', 'Evs', 'MP', 'NO3', 'O2', 'PO4', 'PP',
    'SAL', 'sfcWind', 'Si', 'CDD', 'CSDI', 'CWD', 'FD', 'ID', 'PRCPTOT',
    'R10mm', 'R1mm', 'R20mm', 'R95p', 'R99p', 'Rx1day', 'Rx5day', 'SDII',
    'SU', 'TN10p', 'TN90p', 'TNn', 'TNx', 'TR', 'TX10p', 'TX90p', 'TXn',
    'TXx', 'WSDI'
]
label = 'FCO2'
rf = joblib.load(r"D:/XGB model.pkl")
def add_noise_to_data(data, noise_level):
    noisy_data = data.copy()
    for col in noisy_data.columns:
        if col in attributes:
            noise = np.random.normal(loc=0, scale=noise_level, size=len(noisy_data))
            noisy_data[col] += noise
    return noisy_data
def generate_random_params(param_ranges):
    params = {}
    for param, (lower, upper) in param_ranges.items():
        params[param] = np.random.uniform(lower, upper)
    params['max_depth'] = int(params['max_depth'])
    params['n_estimators'] = int(params['n_estimators'])
    return params
def train_and_predict_label_with_noise(x_train, y_train, params, predict_data, noise_level):
    model = XGBRegressor(**params)
    scaler = StandardScaler()
    x_train_scaled = scaler.fit_transform(x_train[attributes])
    x_train_scaled_df = pd.DataFrame(x_train_scaled, columns=attributes)
    model.fit(x_train_scaled_df, y_train)
    predict_data_copy = add_noise_to_data(predict_data, noise_level)
    predict_data_scaled = scaler.transform(predict_data_copy[attributes])
    predicted_label = model.predict(predict_data_scaled)
    return predicted_label
def generate_random_train_data(data, label, seed, test_size):
    x_train, x_test, y_train, y_test = train_test_split(
        data[attributes], data[label],
        test_size=test_size, random_state=seed
    )
    return x_train, y_train
num_simulations = 100
best_params = {'max_depth': 5, 'n_estimators': 500}
param_ranges = {
    'max_depth': (best_params['max_depth'] - 1, best_params['max_depth'] + 1),
    'n_estimators': (best_params['n_estimators'] - estimator_change,
                     best_params['n_estimators'] + estimator_change)
}
FCO2_simulations = []
predict_data = data[attributes]
for i in tqdm(range(num_simulations), desc="Simulating FCO2", unit="iteration"):
    params = generate_random_params(param_ranges)
    x_train, y_train = generate_random_train_data(data, label, i, test_size)
    predicted_FCO2 = train_and_predict_label_with_noise(
        x_train, y_train, params, predict_data,
        noise_level=noise_level
    )
    FCO2_simulations.append(predicted_FCO2)
    print(predicted_FCO2)
FCO2_simulations_std_mean_ratio = np.std(FCO2_simulations, axis=0) / np.mean(FCO2_simulations, axis=0)
mean_std_mean_ratio = FCO2_simulations_std_mean_ratio.mean()
print(mean_std_mean_ratio)
first_six_columns = data2.iloc[:, :6].copy()
first_six_columns['FCO2_simulations_std_mean_ratio'] = FCO2_simulations_std_mean_ratio
first_six_columns.to_excel(f"D:/XGB_noise{noise_level}_test{test_size}_esti{estimator_change}_{mean_std_mean_ratio}.xlsx", index=False)